import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const CANONICAL_ECOSYSTEM_SENTENCE =
  "Core Holding Corporation is the parent organization that builds and governs infrastructure for agentic digital labor through CoreIdentity Technologies—a platform delivering a three-layer governed execution stack consisting of Sentinel OS, Nexus OS, and SmartNation AI, supported by CoreIdentity Advisory Group and AgentIdentity Systems.";

type FAQItem = {
  q: string;
  a: ReactNode;
};

const faq: FAQItem[] = [
  {
    q: "What is Core Holding Corporation?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          {CANONICAL_ECOSYSTEM_SENTENCE}
        </p>
      </>
    ),
  },
  {
    q: "Why is the parent company called Core Holding Corporation?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          Core Holding Corporation is named to reflect its role as a holding and governance structure, not an operating
          product company. The word Core signals foundational systems, durable intellectual property, governance
          discipline, and long-term control. The name is intentionally direct. It reflects the company’s purpose as a
          parent organization that originates, governs, and scales multiple technology and advisory capabilities without
          being tied to a single product or market cycle.
        </p>
        <p className="text-muted-foreground leading-relaxed mt-4">
          In practical terms, Core Holding Corporation exists to hold and steward core assets—platforms, execution
          layers, and governance frameworks—over the long term.
        </p>
      </>
    ),
  },
  {
    q: "Why is the platform called CoreIdentity Technologies?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          CoreIdentity reflects the belief that identity is the control plane of autonomous execution. In an era of agentic
          systems, identity is no longer only about users—it governs who (or what) an agent is, what it is authorized to
          do, and how its actions remain attributable, constrained, and auditable.
        </p>
        <p className="text-muted-foreground leading-relaxed mt-4">
          The Technologies suffix is deliberate: the platform is infrastructure, not a point solution. It is designed to be
          deployable inside real organizations where governance, permissions, auditability, and evidence are
          non-negotiable.
        </p>
      </>
    ),
  },
  {
    q: "Are Sentinel OS, Nexus OS, and SmartNation AI companies?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          No. Sentinel OS, Nexus OS, and SmartNation AI are execution layers within the CoreIdentity Technologies
          governed execution stack. They are described as layers because they represent distinct operational planes:
          governance, orchestration, and digital labor execution.
        </p>
      </>
    ),
  },
  {
    q: "What does a three-layer governed execution stack mean in practice?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          The stack is designed so autonomous execution can be deployed without surrendering control. Each layer has a
          defined responsibility and an explicit interface with the other layers:
        </p>
        <ul className="mt-4 space-y-3 text-muted-foreground">
          <li>
            <span className="font-semibold text-foreground">Sentinel OS — Governance Layer:</span> policy enforcement,
            approvals, identity boundaries, audit trails, monitoring, and fail-closed controls.
          </li>
          <li>
            <span className="font-semibold text-foreground">Nexus OS — Orchestration Layer:</span> workflow sequencing,
            state management, integrations, exception handling, and reliable recovery under governance constraints.
          </li>
          <li>
            <span className="font-semibold text-foreground">SmartNation AI — Digital Labor Layer:</span> role-based AI
            workers executing real operational processes with clear scope, evidence capture, and controlled escalation.
          </li>
        </ul>
      </>
    ),
  },
  {
    q: "Why does the advisory arm use the name CoreIdentity Advisory Group?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          CoreIdentity Advisory Group exists to operationalize the platform’s governance principles in real
          organizations—before, during, and after deployment. Using the CoreIdentity name is intentional: it signals that
          advisory services are grounded in systems and operating discipline, not generic consulting.
        </p>
        <p className="text-muted-foreground leading-relaxed mt-4">
          The Advisory Group supports readiness, controlled pilots, deployment strategy, and governance operating
          models so adoption can move from experimentation to production without losing accountability.
        </p>
      </>
    ),
  },
  {
    q: "Why is the governance capability named AgentIdentity Systems?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          AgentIdentity Systems is intentionally specific. It reflects infrastructure for agent identity, authorization,
          traceability, and accountability—systems-level primitives rather than features. The name positions the work as
          compliance-first, enterprise-grade, and designed to stand on its own where organizations need governance and
          control layers regardless of the broader stack.
        </p>
      </>
    ),
  },
  {
    q: "How do I request a briefing or partnership discussion?",
    a: (
      <>
        <p className="text-muted-foreground leading-relaxed">
          Use the Contact page to route briefing requests, partnerships, and general inquiries.
        </p>
        <div className="mt-4">
          <Link to="/contact" className="btn btn-primary">
            Go to Contact
          </Link>
        </div>
      </>
    ),
  },
];

export function FAQPage() {
  return (
    <div className="page">
      <section className="section">
        <div className="container">
          <div className="max-w-3xl">
            <p className="eyebrow">FAQ</p>
            <h1 className="h1">Frequently Asked Questions</h1>
            <p className="text-muted-foreground leading-relaxed mt-4">
              {CANONICAL_ECOSYSTEM_SENTENCE} This FAQ explains the naming, structure, and architectural intent behind
              the portfolio.
            </p>
          </div>

          <div className="mt-12 space-y-10">
            {faq.map((item) => (
              <div key={item.q} className="max-w-3xl">
                <h2 className="text-xl font-semibold tracking-tight">{item.q}</h2>
                <div className="mt-3">{item.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default FAQPage;
